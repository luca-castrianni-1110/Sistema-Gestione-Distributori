$(document).ready(function () {

    const urlParams = new URLSearchParams(window.location.search);
    const amountToRecharge = urlParams.get('amount');

    const $cardNumber = $('#card-number');
    const $expiry = $('#expiry-date');
    const $cvc = $('#cvc');
    const $confirmBtn = $('#confirm-btn');


    $cardNumber.on('input', function() {
        let val = $(this).val().replace(/\D/g, '').substring(0,16);
        val = val.replace(/(.{4})/g, '$1 ').trim();
        $(this).val(val);
        checkForm();
    });

    $expiry.on('input', function() {
        let val = $(this).val().replace(/\D/g, '').substring(0,4);
        if (val.length >= 2) {
            val = val.substring(0, 2) + '/' + val.substring(2, 4);
        }
        $(this).val(val);
        checkForm();
    });

    $cvc.on('input', function() {
        $(this).val($(this).val().replace(/\D/g, '').substring(0,3));
        checkForm();
    });

    $('#card-name').on('input', checkForm);

    function checkForm() {
        if ($cardNumber.val().length >= 19 &&
            $('#card-name').val().length > 3 &&
            $expiry.val().length === 5 &&
            $cvc.val().length === 3) {

            $confirmBtn.removeClass('disabled').prop('disabled', false);
        } else {
            $confirmBtn.addClass('disabled').prop('disabled', true);
        }
    }


    $confirmBtn.click(function () {
        if (!amountToRecharge) {
            alert("Errore: Importo mancante. Torna alla home.");
            return;
        }

        $(this).text("Elaborazione in corso...").prop('disabled', true);

        const form = $('<form>', {
            action: '/cliente/ricarica/conferma',
            method: 'POST'
        });

        form.append($('<input>', {
            type: 'hidden',
            name: 'amount',
            value: amountToRecharge
        }));


        $('body').append(form);

        setTimeout(function() {
            form.submit();
        }, 1500);
    });
});