$(document).ready(function() {

    const token = $("meta[name='_csrf']").attr("content");
    const header = $("meta[name='_csrf_header']").attr("content");
    $(document).ajaxSend((e, xhr) => {
        if (token && header) xhr.setRequestHeader(header, token);
    });

    let currentId = null;

    $.ajax({
        url: "/api/export/xml",
        dataType: "xml",
        success: function(xml) {
            const $container = $("#elenco-rapido-distributori");
            $container.empty();
            let trovati = 0;

            $(xml).find("Distributore").each(function() {
                const id = $(this).find("Id").text();
                let stato = $(this).find("Stato").text();
                if(stato === "offline" || stato === "manutenzione") stato = "In Manutenzione";

                const lat = $(this).find("Latitudine").text();
                const lon = $(this).find("Longitudine").text();

                let classeColore = "stato-online"; // Default verde
                let stileColore = "color: #27ae60;"; // Default verde

                if(stato === "Guasto") {
                    classeColore = "stato-guasto";
                    stileColore = "color: red;";
                }
                if(stato === "In Manutenzione" || stato === "Manutenzione") {
                    classeColore = "stato-manutenzione";
                    stileColore = "color: #f39c12;"; // ARANCIONE FISSO
                }

                const html = `
                    <div class="card-anteprima-distributore" data-id="${id}">
                        <strong>ID: ${id}</strong><br>
                        <span class="info-geo"> lat ${lat}, long ${lon}</span>
                        <br>
                        <span class="${classeColore}" style="${stileColore}">${stato}</span>
                    </div>
                `;
                $container.append(html);
                trovati++;
            });

            if (trovati === 0) {
                $container.html("<p>Nessun distributore assegnato.</p>");
            }
        },
        error: function() {
            $("#elenco-rapido-distributori").html("<p style='color:red'>Errore caricamento lista.</p>");
        }
    });

    $(document).on("click", ".card-anteprima-distributore", function() {
        $(".card-anteprima-distributore").removeClass("card-selected");
        $(this).addClass("card-selected");

        const id = $(this).data("id");
        caricaDettagli(id);
    });


    function caricaDettagli(id) {
        if (!id) return;
        currentId = id;

        $.ajax({
            type: "GET",
            url: "/api/manutentore/dettagli/" + id,
            success: function(d) {

                if($("#sezione_stato").is(":hidden")) {
                    $('#sezione_stato').fadeIn();
                    $('html, body').animate({ scrollTop: $("#sezione_stato").offset().top - 20 }, 500);
                }

                let isManutenzioneManuale = (d.stato === "In Manutenzione" || d.stato === "Manutenzione");
                let isGuastoHardware = (d.pompaAcqua === 0 || d.erogatoreLiquido === 0);


                $('#toggle-manutenzione').prop('checked', !isManutenzioneManuale);

                const pulsantiAzioni = $('#btn-ripara-hardware, #btn-rifornimento, #btn-reset-totale');
                if (isManutenzioneManuale) {
                    pulsantiAzioni.prop('disabled', false).css('opacity', '1').css('cursor', 'pointer');
                } else {
                    pulsantiAzioni.prop('disabled', true).css('opacity', '0.5').css('cursor', 'not-allowed');
                }

                if (isManutenzioneManuale) {
                    $('#testo-stato').text("IN MANUTENZIONE").css('color', '#f39c12'); // ARANCIONE
                    $('#scheda-dinamica').css('border-left', '15px solid #f39c12').css('background-color', '#fffaf0');
                } else if (isGuastoHardware) {
                    $('#testo-stato').text("GUASTO").css('color', 'red');
                    $('#scheda-dinamica').css('border-left', '15px solid red').css('background-color', '#fff5f5');
                } else {
                    $('#testo-stato').text("OPERATIVO").css('color', '#27ae60');
                    $('#scheda-dinamica').css('border-left', '15px solid #27ae60').css('background-color', 'white');
                }

                $('#stato-pompa').text(d.pompaAcqua === 1 ? "OK" : "ROTTA")
                    .css('color', d.pompaAcqua === 1 ? 'green' : 'red');
                $('#stato-erogatore').text(d.erogatoreLiquido === 1 ? "OK" : "ROTTO")
                    .css('color', d.erogatoreLiquido === 1 ? 'green' : 'red');

                $('#liv-caffe').text(d.caffe + "%");
                $('#liv-decaf').text(d.decaffeinato + "%");
                $('#liv-orzo').text(d.orzo + "%");
                $('#liv-ginseng').text(d.ginseng + "%");
                $('#liv-the').text(d.the + "%");
                $('#liv-latte').text(d.latte + "%");
                $('#liv-cioccolata').text(d.cioccolata + "%");
                $('#liv-zucchero').text(d.zucchero + "%");
                $('#liv-acqua').text(d.acqua + "%");
                $('#liv-bicchieri').text(d.bicchieri);
                $('#liv-palette').text(d.palette);
            },
            error: () => alert("Errore nel caricamento dettagli!")
        });
    }

    $('#toggle-manutenzione').change(function() {
        if (!currentId) return;

        const isOnline = $(this).is(':checked');
        const nuovoStato = isOnline ? "Online" : "In Manutenzione";

        $.ajax({
            type: "POST",
            url: "/api/manutentore/cambia-stato",
            contentType: "application/json",
            data: JSON.stringify({ id: currentId, stato: nuovoStato }),
            success: () => {
                caricaDettagli(currentId);
                aggiornaListaXML();
            },
            error: () => {
                alert("Errore cambio stato");
                $(this).prop('checked', !isOnline);
            }
        });
    });

    $('#btn-ripara-hardware').click(function() {
        if (!currentId) return;
        $.ajax({
            type: "POST",
            url: "/api/manutentore/ripara-hardware",
            contentType: "application/json",
            data: JSON.stringify({ id: currentId }),
            success: (res) => {
                alert(res);
                caricaDettagli(currentId);
                aggiornaListaXML();
            },
            error: (xhr) => alert(xhr.responseText)
        });
    });

    $('#btn-rifornimento').click(function() {
        if (!currentId) return;
        $.ajax({
            type: "POST",
            url: "/api/manutentore/rifornimento-scorte",
            contentType: "application/json",
            data: JSON.stringify({ id: currentId }),
            success: (res) => {
                alert(res);
                caricaDettagli(currentId);
            },
            error: (xhr) => alert(xhr.responseText)
        });
    });

    $('#btn-reset-totale').click(function() {
        if (!currentId || !confirm("Confermi reset totale?")) return;
        $.ajax({
            type: "POST",
            url: "/api/manutentore/ripristina-forniture",
            contentType: "application/json",
            data: JSON.stringify({ id: currentId }),
            success: (res) => {
                alert(res);
                caricaDettagli(currentId);
                aggiornaListaXML();
            },
            error: (xhr) => alert(xhr.responseText)
        });
    });

    function aggiornaListaXML() {
        $.ajax({
            url: "/api/export/xml",
            dataType: "xml",
            success: function(xml) {
                $(xml).find("Distributore").each(function() {
                    const id = $(this).find("Id").text();
                    let stato = $(this).find("Stato").text();
                    if(stato === "offline" || stato === "manutenzione") stato = "In Manutenzione";

                    const $card = $(`.card-anteprima-distributore[data-id='${id}']`);
                    const $spanStato = $card.find("span").last();

                    $spanStato.text(stato);

                    let colore = "#27ae60"; // verde
                    if(stato === "Guasto") colore = "red";
                    if(stato === "In Manutenzione") colore = "#f39c12"; // ARANCIONE

                    $spanStato.css("color", colore);
                });
            }
        });
    }
});