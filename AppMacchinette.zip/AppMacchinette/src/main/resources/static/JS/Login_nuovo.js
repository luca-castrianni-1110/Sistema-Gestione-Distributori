document.addEventListener("DOMContentLoaded", () => {

    const sezioneRegistrazione = document.getElementById('sezione_registrazione');
    const mostraRegistrazioneBtn = document.getElementById('mostraRegistrazioneBtn');
    const formRegistrazione = document.querySelector(".Registrazione");
    const bannerRegistrazione = document.getElementById("banner-registrazione");

    if (sezioneRegistrazione) {
        sezioneRegistrazione.classList.add('nascosto');
    }

    if (mostraRegistrazioneBtn) {
        mostraRegistrazioneBtn.addEventListener('click', () => {
            sezioneRegistrazione.classList.toggle('nascosto');
            if (sezioneRegistrazione.classList.contains('nascosto')) {
                mostraRegistrazioneBtn.textContent = "Registrazione";
            } else {
                mostraRegistrazioneBtn.textContent = "Annulla Registrazione";
            }
        });
    }

    if (formRegistrazione) {
        formRegistrazione.addEventListener("submit", async (e) => {
            e.preventDefault();

            const token = document.querySelector("meta[name='_csrf']")?.content;
            const header = document.querySelector("meta[name='_csrf_header']")?.content;

            const password = document.getElementById("Password_registrazione").value;
            const conferma = document.getElementById("Conferma_Password_registrazione").value;

            if (password !== conferma) {
                alert("Le password non coincidono.");
                return;
            }

            const datiRegistrazione = {
                nome: document.getElementById("User_Registrazione").value,
                cognome: document.getElementById("Cognome_Registrazione").value,
                username: document.getElementById("Username_Scelto").value,
                email: document.getElementById("Email_Registrazione").value,
                password: password
            };

            try {
                const headers = { 'Content-Type': 'application/json' };
                if (token && header) headers[header] = token;

                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(datiRegistrazione)
                });

                const resultText = await response.text();

                if (response.ok && resultText === "OK") {
                    bannerRegistrazione.innerHTML = `Registrazione OK! Benvenuto <strong>${datiRegistrazione.username}</strong>`;
                    bannerRegistrazione.className = "banner-visibile";

                    sezioneRegistrazione.classList.add('nascosto');
                    mostraRegistrazioneBtn.textContent = "Registrazione";
                    formRegistrazione.reset();

                    setTimeout(() => {
                        bannerRegistrazione.className = "banner-nascosto";
                    }, 5000);

                } else {
                    alert(resultText);
                }
            } catch (error) {
                console.error("Errore:", error);
                alert("Errore di connessione col server.");
            }
        });
    }
});