$(document).ready(function () {

    const userId = $("#user-db-id").val();
    const csrfToken = $("meta[name='_csrf']").attr("content");
    const csrfHeader = $("meta[name='_csrf_header']").attr("content");

    const $displayCredito = $("#credit-amount");

    $.ajaxSetup({
        beforeSend: function(xhr) {
            if (csrfToken && csrfHeader) xhr.setRequestHeader(csrfHeader, csrfToken);
        }
    });

    const $connectBtn = $('#connect-btn');
    const $disconnectBtn = $('#disconnect-btn');
    const $distributorInput = $('#distributor-id');
    const $statusDisplay = $('#connected-id-display');
    const $boxErrore = $('#box-errore');
    const $testoErrore = $('#testo-errore');

    function aggiornaCreditoRealTime() {
        $.ajax({
            url: "/api/cliente/credito-attuale",
            method: "GET",
            success: function(nuovoCredito) {
                if ($displayCredito.length > 0 && nuovoCredito !== null) {
                    let testoFormat = nuovoCredito.toFixed(2).replace('.', ',') + " €";
                    $displayCredito.text(testoFormat);
                }
            },
        });
    }

    setInterval(aggiornaCreditoRealTime, 2000);

    $connectBtn.click(function () {
        const idDistrib = $distributorInput.val().trim();
        if (!idDistrib) return;

        $boxErrore.hide();

        $.post("/api/connessione/login-fisico", {
            idDistributore: idDistrib,
            idCliente: userId
        })
            .done(function() {
                $statusDisplay.text("Connesso a ID: " + idDistrib).css("color", "green");
                $distributorInput.prop('disabled', true);
                $connectBtn.prop('disabled', true);
                $disconnectBtn.prop('disabled', false);

                localStorage.setItem("distributoreConnesso", idDistrib);
            })
            .fail(function(xhr) {
                let msg = xhr.responseText || "Errore di connessione";
                $testoErrore.text(msg);
                $boxErrore.fadeIn();
            });
    });

    $disconnectBtn.click(function () {
        const idDistrib = $distributorInput.val() || localStorage.getItem("distributoreConnesso");

        $.post("/api/connessione/logout-fisico", { idDistributore: idDistrib })
            .always(function() {
                resetUI();
            });
    });

    function resetUI() {
        $statusDisplay.text("Non Connesso").css("color", "black");
        $distributorInput.prop('disabled', false).val('');
        $connectBtn.prop('disabled', false);
        $disconnectBtn.prop('disabled', true);
        localStorage.removeItem("distributoreConnesso");
        $boxErrore.hide();
    }

    $('.pulsante-importo').click(function() {
        $('.pulsante-importo').removeClass('active-amount');
        $(this).addClass('active-amount');
        $('#custom-amount').val('');
        $('#recharge-btn').prop('disabled', false).data('amount', $(this).data('amount'));
    });

    $('#custom-amount').on('input', function() {
        $('.pulsante-importo').removeClass('active-amount');
        let val = parseFloat($(this).val());
        if(val > 0) $('#recharge-btn').prop('disabled', false).data('amount', val);
        else $('#recharge-btn').prop('disabled', true);
    });

    $('#recharge-btn').click(function() {
        let amount = $(this).data('amount');
        window.location.href = "/cliente/pagamento?amount=" + amount;
    });

    const savedId = localStorage.getItem("distributoreConnesso");
    if(savedId) {
        $distributorInput.val(savedId);
        $statusDisplay.text("Connesso a ID: " + savedId).css("color", "green");
        $distributorInput.prop('disabled', true);
        $connectBtn.prop('disabled', true);
        $disconnectBtn.prop('disabled', false);
    }
});