document.addEventListener("DOMContentLoaded", function() {
    const barra = document.getElementById("riempimento");
    const messaggio = document.getElementById("messaggio-caricamento");
    const bottone = document.getElementById("pulsante-pronto");
    const titolo = document.getElementById("titolo-caricamento");

    let width = 0;
    const stati = ["Scaldando acqua...", "Macinatura...", "Erogazione...", "Aggiunta Zucchero...", "Quasi pronto..."];

    const timer = setInterval(function() {
        if (width >= 100) {
            clearInterval(timer);
            titolo.textContent = "Prodotto Pronto!";
            messaggio.textContent = "Grazie per l'acquisto.";
            bottone.style.display = "block";
        } else {
            width++;
            barra.style.width = width + "%";
            let index = Math.floor((width / 100) * stati.length);
            if(stati[index]) messaggio.textContent = stati[index];
        }
    }, 40);
});