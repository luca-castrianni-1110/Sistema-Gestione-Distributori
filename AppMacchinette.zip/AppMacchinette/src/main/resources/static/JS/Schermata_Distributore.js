$(document).ready(function() {


    const distributoreId = $("#id-distributore-sicuro").val();

    const csrfToken = $("meta[name='_csrf']").attr("content") || "";
    const csrfHeader = $("meta[name='_csrf_header']").attr("content") || "X-CSRF-TOKEN";

    const $pulsantiBevanda = $(".pulsante-bevanda");
    const $pulsantiZucchero = $(".pulsante-zucchero");
    const $pulsanteAcquista = $("#pulsante-acquista");
    const $nomeUtente = $("#nome-utente");
    const $credito = $("#credito-attuale");
    const $header = $(".intestazione-utente-distributore");

    let bevandaSelezionata = null;
    let zuccheroSelezionato = 2;
    let creditoAttuale = 0;

    const ricette = {
        'cappuccino': ['latte', 'caffe'],
        'caffe_macchiato': ['latte', 'caffe'],
        'cioccolata': ['cioccolata', 'latte'],
        'caffe_ginseng': ['ginseng'],
        'the_limone': ['the'],
        'caffe_orzo': ['orzo'],
        'caffe_espresso': ['caffe'],
        'caffe_lungo': ['caffe'],
        'caffe_decaffeinato': ['decaffeinato']
    };


    $pulsantiZucchero.click(function() {
        if ($(this).prop("disabled")) return;

        $pulsantiZucchero.removeClass("selezionato");
        $(this).addClass("selezionato");

        zuccheroSelezionato = $(this).data("livello");
        console.log("Zucchero impostato a: " + zuccheroSelezionato);
    });


    $pulsantiBevanda.click(function() {
        if ($(this).prop("disabled") || $(this).hasClass("esaurito")) return;

        $pulsantiBevanda.removeClass("selezionato");
        $(this).addClass("selezionato");

        bevandaSelezionata = $(this).data("id-bevanda");
        const prezzo = parseFloat($(this).data("prezzo"));

        $pulsanteAcquista.text("ACQUISTA (" + prezzo.toFixed(2) + " €)");
        $pulsanteAcquista.prop("disabled", false).show();
    });


    $pulsanteAcquista.click(function(e) {
        e.preventDefault();

        if (!bevandaSelezionata) return;

        const prezzo = parseFloat($(".pulsante-bevanda.selezionato").data("prezzo"));

        if (creditoAttuale >= prezzo) {

            const form = $('<form>', {
                action: '/pagamento/eroga/' + distributoreId,
                method: 'POST'
            });

            form.append($('<input>', { type: 'hidden', name: 'prezzo', value: prezzo }));
            form.append($('<input>', { type: 'hidden', name: 'bevanda', value: bevandaSelezionata }));
            form.append($('<input>', { type: 'hidden', name: 'zucchero', value: zuccheroSelezionato }));

            if (csrfToken) {
                form.append($('<input>', { type: 'hidden', name: '_csrf', value: csrfToken }));
            }

            $('body').append(form);
            form.submit();
        } else {
            alert("Credito insufficiente! Effettua la ricarica .");
        }
    });


    function aggiornaStato() {
        $.ajax({
            url: "/api/macchinetta/" + distributoreId + "/verifica-connessione",
            method: "GET",
            success: function(data) {

                if (data.stato !== "Online") {
                    bloccaTuttoPerGuasto(data.stato);
                    return;
                } else {
                    $header.css("background", "linear-gradient(135deg, #c7a77d, #b18d68)");
                }

                if (data.connesso) {
                    $nomeUtente.text("Utente: " + data.clienteNome).css("color", "#ffffff");
                    creditoAttuale = data.credito;
                    $credito.text(creditoAttuale.toFixed(2) + " €");

                    $pulsantiZucchero.prop("disabled", false);

                    if (bevandaSelezionata) {
                        $pulsanteAcquista.prop("disabled", false);
                    } else {

                        $pulsanteAcquista.text("ACQUISTA");
                        $pulsanteAcquista.prop("disabled", true);
                    }

                    gestisciEsauriti(data);

                } else {
                    $nomeUtente.text("In attesa di connessione");
                    $credito.text("0.00 €");
                    creditoAttuale = 0;

                    $pulsantiBevanda.prop("disabled", true).removeClass("selezionato").removeClass("esaurito").css("opacity", "1");
                    $pulsantiZucchero.prop("disabled", true);

                    $pulsanteAcquista.prop("disabled", true).text("INSERIRE TESSERA");

                    bevandaSelezionata = null;
                }
            },
            error: function() {
                console.log("Errore connessione server polling");
            }
        });
    }


    function gestisciEsauriti(data) {
        $pulsantiBevanda.each(function() {
            const $btn = $(this);
            const idBevanda = $btn.data("id-bevanda");
            const ingredienti = ricette[idBevanda];
            let disponibile = true;

            if (data.scortaBicchieri < 1) disponibile = false;

            if (ingredienti) {
                ingredienti.forEach(ing => {
                    const key = "scorta" + ing.charAt(0).toUpperCase() + ing.slice(1);
                    if (data[key] < 1) disponibile = false;
                });
            }

            if (!disponibile) {
                $btn.prop("disabled", true).addClass("esaurito");
                $btn.css("opacity", "0.5").css("background-color", "#ccc");

                if ($btn.hasClass("selezionato")) {
                    $btn.removeClass("selezionato");
                    bevandaSelezionata = null;
                    $pulsanteAcquista.prop("disabled", true).text("ACQUISTA");
                }
            } else {
                if (!$btn.hasClass("selezionato")) {
                    $btn.prop("disabled", false).removeClass("esaurito");
                    $btn.css("opacity", "1").css("background-color", "#fffaf4");
                }
            }
        });
    }


    function bloccaTuttoPerGuasto(stato) {
        $nomeUtente.text("" + stato.toUpperCase() + "");
        $header.css("background", "linear-gradient(135deg, #c0392b, #8e44ad)");
        $pulsantiBevanda.prop("disabled", true).css("opacity", "0.5");
        $pulsantiZucchero.prop("disabled", true);
        $pulsanteAcquista.text("FUORI SERVIZIO").prop("disabled", true);
    }


    function inviaHeartbeat() {
        $.ajax({

            url: "http://localhost:8081/monitoraggio_mongo_war_exploded/distributori/" + distributoreId + "/heartbeat",
            method: "POST",
            success: function() {
                $("#heartbeat-dot").css("background-color", "#0f0");
            },
            error: function() {
                $("#heartbeat-dot").css("background-color", "#f00");
            }
        });
    }


    setInterval(aggiornaStato, 2000);
    setInterval(inviaHeartbeat, 60000);

    aggiornaStato();
    inviaHeartbeat();
});