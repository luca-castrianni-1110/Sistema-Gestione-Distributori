$(document).ready(function () {

    const token = $("meta[name='_csrf']").attr("content");
    const header = $("meta[name='_csrf_header']").attr("content");

    $(document).ajaxSend(function(e, xhr, options) {
        if (token && header) {
            xhr.setRequestHeader(header, token);
        }
    });

    const $listaDistributori = $(".lista-distributori");
    const $listaManutentori = $(".lista-manutentori");

    const $tabellaDistributori = $("#tabella-distributori");
    const $tabellaAddetti = $("#tabella-addetti");

    let distributori = [];
    let addetti = [];

    function creaTabellaDistributori() {
        $tabellaDistributori.html(`
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Latitudine</th>
                        <th>Longitudine</th>
                        <th>Stato</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        `);
        return $tabellaDistributori.find("tbody");
    }

    function creaTabellaAddetti() {
        $tabellaAddetti.html(`
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Nome</th>
                        <th>Cognome</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        `);
        return $tabellaAddetti.find("tbody");
    }

    const $tbodyDistributori = creaTabellaDistributori();
    const $tbodyAddetti = creaTabellaAddetti();


    function caricaXML(url, callback) {
        $.ajax({
            url: url, dataType: "xml",
            success: (xml) => callback(xml),
            error: (xhr) => console.error("Errore XML " + url, xhr)
        });
    }

    caricaXML("/api/export/xml", function(xml) {
        distributori = [];
        $(xml).find("Distributore").each(function () {
            const $d = $(this);
            const id = $d.find("Id").text();
            if (id) {
                distributori.push({
                    id: id,
                    lat: $d.find("Latitudine").text() || "-",
                    lon: $d.find("Longitudine").text() || "-",
                    stato: $d.find("Stato").text() || "N/D"
                });
            }
        });

        aggiornaTabellaDistributori();
        $listaDistributori.empty();
        distributori.forEach(d => $listaDistributori.append(creaDistributore(d)));
    });

    caricaXML("/api/export/manutentori/xml", function(xml) {
        addetti = [];
        $(xml).find("addetto").each(function () {
            const $a = $(this);
            addetti.push({
                id: $a.find("id").text(),
                username: $a.find("username").text(),
                nome: $a.find("nome").text(),
                cognome: $a.find("cognome").text()
            });
        });

        // Aggiorna UI
        aggiornaTabellaAddetti();
        aggiornaListaManutentori();
    });



    function aggiornaTabellaDistributori() {
        $tbodyDistributori.empty();
        distributori.forEach(d => {
            $tbodyDistributori.append(`
                <tr>
                    <td>${d.id}</td>
                    <td>${d.lat}</td>
                    <td>${d.lon}</td>
                    <td>${d.stato}</td>
                </tr>
            `);
        });
    }

    function aggiornaTabellaAddetti() {
        $tbodyAddetti.empty();
        addetti.forEach(a => {
            $tbodyAddetti.append(`
                <tr>
                    <td>${a.id}</td>
                    <td style="font-weight: bold; color: #2c3e50;">${a.username}</td>
                    <td>${a.nome}</td>
                    <td>${a.cognome}</td>
                </tr>
            `);
        });
    }

    function aggiornaListaManutentori() {
        $listaManutentori.empty();
        addetti.forEach(a => {
            $listaManutentori.append(`
                <div class="manutentore-item">
                    <span class="manutentore-nome">${a.nome} ${a.cognome}</span>
                    <span class="manutentore-email">${a.username}</span>
                </div>
            `);
        });
    }

    function creaDistributore(d) {
        let statoLower = d.stato.toLowerCase().trim();

        if(statoLower === "offline" || statoLower === "in manutenzione") {
            d.stato = "Manutenzione";
            statoLower = "manutenzione";
        }

        const $div = $(`
            <div class="distributore-item" data-id="${d.id.toLowerCase()}" data-lat="${d.lat}" data-lon="${d.lon}" data-stato="${statoLower}">
                <div class="info-distributore">
                    <span class="distributore-nome">ID: ${d.id}</span>
                    <span class="distributore-indirizzo">Lat: ${d.lat}, Lon: ${d.lon}</span>
                    <span class="distributore-stato">${d.stato}</span>
                </div>
                <label class="interruttore">
                    <input type="checkbox" ${statoLower === "online" ? "checked" : ""} ${statoLower === "guasto" ? "disabled" : ""}>
                    <span class="slider"></span>
                </label>
            </div>
        `);

        const $statoText = $div.find(".distributore-stato");
        const $toggle = $div.find("input[type='checkbox']");

        if (statoLower === "online") $statoText.addClass("stato-online");
        if (statoLower === "guasto") $statoText.addClass("stato-guasto");
        if (statoLower === "manutenzione") $statoText.addClass("stato-manutenzione"); // Ora questo scatterà anche per "In Manutenzione"

        $toggle.on("change", function () {
            const isChecked = this.checked;
            const nuovoStato = isChecked ? "Online" : "Manutenzione";

            $.ajax({
                type: "POST",
                url: "/api/gestore/cambia-stato",
                contentType: "application/json",
                data: JSON.stringify({ idDistributore: d.id, nuovoStato: nuovoStato }),
                success: function() {
                    if (isChecked) {
                        $statoText.text("Online").removeClass("stato-manutenzione").addClass("stato-online");
                        $div.attr("data-stato", "online");
                        d.stato = "Online";
                    } else {
                        $statoText.text("Manutenzione").removeClass("stato-online").addClass("stato-manutenzione");
                        $div.attr("data-stato", "manutenzione");
                        d.stato = "Manutenzione";
                    }
                },
                error: function(xhr) {
                    alert("Errore cambio stato: " + xhr.responseText);
                    $toggle.prop("checked", !isChecked); // Torna indietro in caso di errore
                }
            });
        });

        return $div;
    }

    $("#ricerca-distributori").on("input", function () {
        const q = $(this).val().toLowerCase().trim();
        $(".distributore-item").each(function () {
            const match = $(this).data("id").toString().includes(q) ||
                $(this).data("stato").toString().includes(q);
            $(this).toggle(match);
        });
    });

    $(".scheda-manutentori .barra-ricerca input").on("input", function () {
        const q = $(this).val().toLowerCase().trim();
        $(".manutentore-item").each(function () {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(q));
        });
    });


    $("#form-aggiungi-distributore").on("submit", function (e) {
        e.preventDefault();
        const lat = $("#new-dist-lat").val().trim();
        const lon = $("#new-dist-lon").val().trim();
        const username = $("#new-dist-username").val().trim();
        const password = $("#new-dist-password").val().trim();

        if (!lat || !lon || !username || !password) {
            return alert("Compila tutti i campi!");
        }

        if (isNaN(lat) || isNaN(lon)) return alert("Latitudine e Longitudine devono essere numeri.");

        const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;
        if (!passwordRegex.test(password)) {
            return alert("Password debole! (Min 8 char, Maiusc, Minusc, Num, Speciale)");
        }

        const payload = {

            latitudine: parseFloat(lat),
            longitudine: parseFloat(lon),
            username: username,
            password: password
        };

        $.ajax({
            type: "POST",
            url: "/api/gestore/aggiungi-distributore",
            contentType: "application/json",
            data: JSON.stringify(payload),
            success: function(response) {
                // Il server risponderà: "Distributore creato... ID Assegnato: 1234"
                alert(response);

                $("#new-dist-lat").val("");
                $("#new-dist-lon").val("");
                $("#new-dist-username").val("");
                $("#new-dist-password").val("");

                location.reload();
            },
            error: function(xhr) {
                alert("Errore: " + xhr.responseText);
            }
        });
    });

    $("#form-rimuovi-distributore").on("submit", function (e) {
        e.preventDefault();
        const id = $("#remove-dist-id").val().trim();
        if(!id) return;
        if(!confirm("Eliminare distributore " + id + "?")) return;

        $.ajax({
            type: "POST", url: "/api/gestore/rimuovi-distributore",
            contentType: "application/json", data: JSON.stringify({ id: id }),
            success: (res) => { alert(res); location.reload(); },
            error: (xhr) => alert("Errore: " + xhr.responseText)
        });
    });

    $("#form-aggiungi-addetto").on("submit", function (e) {
        e.preventDefault();
        const payload = {
            username: $("#new-addetto-username").val().trim(),
            nome: $("#new-addetto-nome").val().trim(),
            cognome: $("#new-addetto-cognome").val().trim(),
            password: $("#new-addetto-password").val().trim()
        };

        if(!payload.username || !payload.password) return alert("Compila tutto");

        $.ajax({
            type: "POST", url: "/api/gestore/aggiungi-manutentore",
            contentType: "application/json", data: JSON.stringify(payload),
            success: (res) => { alert(res); location.reload(); },
            error: (xhr) => alert("Errore: " + xhr.responseText)
        });
    });

    $("#form-rimuovi-addetto").on("submit", function (e) {
        e.preventDefault();
        const user = $("#remove-addetto-id").val().trim();
        if(!user) return;
        if(!confirm("Licenziare " + user + "?")) return;

        $.ajax({
            type: "POST", url: "/api/gestore/rimuovi-manutentore",
            contentType: "application/json", data: JSON.stringify({ username: user }),
            success: (res) => { alert(res); location.reload(); },
            error: (xhr) => alert("Errore: " + xhr.responseText)
        });
    });
});