package com.example.appmacchinette.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DistributoreRequest {
    private String id;


    @JsonProperty("latitudine")
    private Double lat;

    @JsonProperty("longitudine")
    private Double lon;

    private String username;
    private String password;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Double getLat() { return lat; }
    public void setLat(Double lat) { this.lat = lat; }

    public Double getLon() { return lon; }
    public void setLon(Double lon) { this.lon = lon; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}