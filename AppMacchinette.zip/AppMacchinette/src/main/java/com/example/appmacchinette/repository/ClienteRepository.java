package com.example.appmacchinette.repository;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Cliente findByUser(User user);
}