package com.example.appmacchinette.controller.Area_Gestore;

import com.example.appmacchinette.dto.DistributoreRequest;
import com.example.appmacchinette.service.Service_Area_Gestore.DistributoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;

@RestController
@RequestMapping("/api/gestore")
public class AmministrazioneDistributoriController {

    @Autowired private DistributoreService distributoreService;

    @PostMapping("/aggiungi-distributore")
    public ResponseEntity<String> aggiungiDistributore(@RequestBody DistributoreRequest req, Principal principal) {
        try {
            Long newId = distributoreService.aggiungiDistributore(req, principal.getName());
            return ResponseEntity.ok("Distributore creato con Successo! ID Assegnato: " + newId);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore: " + e.getMessage());
        }
    }

    @PostMapping("/rimuovi-distributore")
    public ResponseEntity<String> rimuoviDistributore(@RequestBody DistributoreRequest req, Principal principal) {
        try {
            distributoreService.rimuoviDistributore(req.getId(), principal.getName());
            return ResponseEntity.ok("Distributore rimosso.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore: " + e.getMessage());
        }
    }
}