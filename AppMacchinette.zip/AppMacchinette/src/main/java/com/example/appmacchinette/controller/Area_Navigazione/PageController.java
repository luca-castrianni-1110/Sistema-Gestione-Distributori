package com.example.appmacchinette.controller.Area_Navigazione;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.ClienteRepository;
import com.example.appmacchinette.repository.DistributoreRepository;
import com.example.appmacchinette.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import jakarta.servlet.http.HttpServletRequest;
import java.security.Principal;

@Controller
public class PageController {

    @Autowired private UserRepository userRepository;
    @Autowired private ClienteRepository clienteRepository;
    @Autowired private DistributoreRepository distributoreRepository;

    @GetMapping("/login")
    public String login() {
        return "Login_Utente";
    }

    @GetMapping("/cliente/home")
    public String home(Model model, Principal principal) {
        if (principal == null) return "redirect:/login";

        User user = userRepository.findByUsername(principal.getName()).orElse(null);
        Cliente c = clienteRepository.findByUser(user);

        if (c != null) {
            model.addAttribute("credito", c.getCredito());
            model.addAttribute("nome", c.getNome());
            model.addAttribute("cognome", c.getCognome());
            model.addAttribute("clienteId", c.getId());
        } else {
            model.addAttribute("credito", 0.0);
        }
        return "Schermata_Utente";
    }

    @GetMapping("/cliente/profilo")
    public String profilo(Model model, Principal principal) {
        return home(model, principal);
    }

    @PostMapping("/cliente/connetti")
    @Transactional
    public String connettiDistributore(@RequestParam("idDistributore") String idString, Principal principal) {
        try {
            Long id = Long.parseLong(idString.trim());
            Distributore d = distributoreRepository.findById(id).orElse(null);

            if (d == null) return "redirect:/cliente/home?errore=distributore_non_trovato";

            if (!"Online".equalsIgnoreCase(d.getStato())) {
                return "redirect:/cliente/home?errore=macchina_guasta&stato=" + d.getStato();
            }

            User user = userRepository.findByUsername(principal.getName()).orElse(null);
            if (user != null) {
                Cliente c = clienteRepository.findByUser(user);
                Distributore vecchio = distributoreRepository.findByUtenteConnesso(c);
                if (vecchio != null) {
                    vecchio.setUtenteConnesso(null);
                    distributoreRepository.save(vecchio);
                }
                d.setUtenteConnesso(c);
                distributoreRepository.save(d);
                return "redirect:/cliente/distributore?id=" + id;
            }
        } catch (NumberFormatException e) {
            return "redirect:/cliente/home?errore=id_non_valido";
        }
        return "redirect:/cliente/home?errore=generico";
    }

    //L AVEVO SCRITTA PERCHE VOLEVO FAR APPARIRE NELLA SCHERMATA DEL CLIENTE LA MACCHINETTA E COMPRARE DIRETTAMENTE DA LI
    //MA HO PREFERITO FARE L ACQUISTO SOLO DALLA MACCHINETTA MA LA LASCIO PER FUTURE IMPLEMENTAZIONI
    @GetMapping("/cliente/distributore")
    public String visualizzaDistributore(@RequestParam(value = "id", required = false) String id, Model model) {
        if (id == null || id.isEmpty()) return "redirect:/cliente/home?errore=id_mancante";

        try {
            Long idNumerico = Long.parseLong(id);
            Distributore d = distributoreRepository.findById(idNumerico).orElse(null);

            if (d != null) {
                if (!"Online".equalsIgnoreCase(d.getStato())) {
                    return "redirect:/cliente/home?errore=macchina_guasta&stato=" + d.getStato();
                }
                model.addAttribute("idMacchina", d.getId());
                model.addAttribute("distributore", d);
                if (d.getUtenteConnesso() != null) {
                    model.addAttribute("clienteNome", d.getUtenteConnesso().getNome());
                    model.addAttribute("credito", d.getUtenteConnesso().getCredito());
                } else {
                    model.addAttribute("clienteNome", "In attesa di collegamento...");
                    model.addAttribute("credito", 0.00);
                }
                return "Schermata_Distributore";
            }
        } catch (NumberFormatException e) { }
        return "redirect:/cliente/home?errore=distributore_non_trovato";
    }



    @GetMapping("/distributore/interfaccia")//Visuale che vedo nel distributore
    public String interfacciaIntelligente(Model model, Principal principal, @RequestParam(required = false) String id) {
        if (principal == null) return "redirect:/login";

        String username = principal.getName();
        User userLoggato = userRepository.findByUsername(username).orElse(null);
        Distributore d = null;

        if (userLoggato != null && "DISTRIBUTORE".equals(userLoggato.getRuolo().toString())) {
            d = distributoreRepository.findByUser(userLoggato);
        } else if (id != null) {
            try { d = distributoreRepository.findById(Long.parseLong(id)).orElse(null); } catch (Exception e) {}
        }

        if (d != null) {
            model.addAttribute("distributore", d);
            model.addAttribute("idMacchina", d.getId());
            if (d.getUtenteConnesso() != null) {
                model.addAttribute("clienteNome", d.getUtenteConnesso().getNome());
                model.addAttribute("credito", d.getUtenteConnesso().getCredito());
            }
            return "Schermata_Distributore";
        }
        return "redirect:/cliente/home?error=accesso_negato";
    }

    @GetMapping("/gestore/dashboard")
    public String dashboardGestore(Model model, Principal principal) {
        model.addAttribute("nomeGestore", principal != null ? principal.getName() : "Gestore");
        return "Schermata_Gestore_Del_Sistema";
    }

    @GetMapping("/manutentore/tasks")
    public String tasks(Model model, Principal principal) {
        model.addAttribute("username", principal != null ? principal.getName() : "Operatore");
        return "Schermata_Addetto_Manutenzione";
    }

    @GetMapping("/api/cliente/credito-attuale")
    @ResponseBody //restituisce un dato puro e mi serve per il frontend per aggiornare il credito
    public ResponseEntity<Double> getCreditoRealTime(Principal principal) {
        if (principal == null) return ResponseEntity.status(401).build();

        String username = principal.getName();
        User user = userRepository.findByUsername(username).orElse(null);

        if (user != null) {
            Cliente cliente = clienteRepository.findByUser(user);
            if (cliente != null) {
                return ResponseEntity.ok(cliente.getCredito());
            }
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/cliente/logout-distributore")
    public String disconnettiELogout(Principal principal, HttpServletRequest request) {
        try {
            if (principal != null) {
                User user = userRepository.findByUsername(principal.getName()).orElse(null);

                if (user != null) {
                    Cliente c = clienteRepository.findByUser(user);
                    if (c != null) {
                        Distributore d = distributoreRepository.findByUtenteConnesso(c);
                        if (d != null) {
                            d.setUtenteConnesso(null);
                            distributoreRepository.save(d);
                        }
                    }
                }
            }
            SecurityContextHolder.clearContext();
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }

            return "redirect:/login?logout=true";

        } catch (Exception e) {
            System.err.println("Errore logout non eseguito: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/login?error=logout_failed";
        }
    }
}