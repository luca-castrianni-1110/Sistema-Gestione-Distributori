package com.example.appmacchinette.repository;

import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GestoreRepository extends JpaRepository<Gestore, Long> {
    Optional<Gestore> findByUser(User user);
}
