package com.example.appmacchinette.repository;

import com.example.appmacchinette.entity.Manutentore;
import com.example.appmacchinette.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ManutentoreRepository extends JpaRepository<Manutentore, Long> {

    List<Manutentore> findByGestoreId(Long gestoreId);
    Manutentore findByUser(User user);
}
