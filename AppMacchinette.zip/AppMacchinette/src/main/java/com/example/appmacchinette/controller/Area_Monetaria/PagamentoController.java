package com.example.appmacchinette.controller;

import com.example.appmacchinette.service.Service_Area_Monetaria.PagamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/pagamento")
public class PagamentoController {

    @Autowired private PagamentoService pagamentoService;

    @PostMapping("/eroga/{idDistributore}")
    public String gestisciPagamento(@PathVariable Long idDistributore,
                                    @RequestParam("prezzo") Double prezzo,
                                    @RequestParam("bevanda") String bevanda,
                                    @RequestParam(value = "zucchero", defaultValue = "2") Integer zucchero,
                                    Model model) {

        String risultato = pagamentoService.eseguiErogazione(idDistributore, prezzo, bevanda, zucchero);

        if ("OK".equals(risultato)) {
            System.out.println("Erogazione OK. Passo ID=" + idDistributore + " alla schermata di caricamento.");
            model.addAttribute("idDistributore", idDistributore);
            return "Schermata_Caricamento_Acquisto";
        } else {
            String redirectError = "redirect:/cliente/distributore?id=" + idDistributore;
            if ("distributore_non_trovato".equals(risultato)) return "redirect:/cliente/home?errore=distributore_non_trovato";
            return redirectError + "&errore=" + risultato;
        }
    }
}