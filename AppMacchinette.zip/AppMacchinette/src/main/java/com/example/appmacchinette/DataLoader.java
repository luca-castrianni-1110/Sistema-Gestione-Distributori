package com.example.appmacchinette;

import com.example.appmacchinette.entity.*;
import com.example.appmacchinette.repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;

//@Component
public class DataLoader implements CommandLineRunner {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired private UserRepository userRepository;
    @Autowired private GestoreRepository gestoreRepository;
    @Autowired private ManutentoreRepository manutentoreRepository;
    @Autowired private DistributoreRepository distributoreRepository;
    @Autowired private ClienteRepository clienteRepository;
    @Autowired private org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        System.out.println("--- Avvio Popolamento Dati ---");

        // Pulizia nell'ordine corretto per non violare i vincoli (FK)
        distributoreRepository.deleteAllInBatch();
        manutentoreRepository.deleteAllInBatch();
        clienteRepository.deleteAllInBatch();
        gestoreRepository.deleteAllInBatch();
        userRepository.deleteAllInBatch();

        // Fondamentale: pulisce la cache di Hibernate dopo le delete
        entityManager.flush();
        entityManager.clear();

        String p = passwordEncoder.encode("pass123");

        // GESTORI
        Gestore g1 = creaGestoreCompleto("mario", p, "Mario", "Rossi");
        Gestore g2 = creaGestoreCompleto("laura", p, "Laura", "Bianchi");
        Gestore g3 = creaGestoreCompleto("roberto", p, "Roberto", "Neri");

        // MANUTENTORI
        creaManutentoreCompleto("luigi", p, "Luigi", "Verdi", g1);
        creaManutentoreCompleto("anna", p, "Anna", "Gialli", g2);
        creaManutentoreCompleto("paolo", p, "Paolo", "Viola", g3);

        // CLIENTI
        creaClienteCompleto("francesco", p, "Francesco", "Macaluso", "francesco_2801@gamil.com", 100.0);
        creaClienteCompleto("sofia", p, "Sofia", "Romano", "sofia_12233@gmail.com", 25.50);
        creaClienteCompleto("luca", p, "Luca", "Mistretta", "luca_mis45@gmail.com", 0.50);
        creaClienteCompleto("giulia", p, "Giulia", "Buongiorno", "giulia_buon@gmail.com", 15.0);
        creaClienteCompleto("ale", p, "Alessandro", "Moscarino", "alex.mos@gmail.com", 10.0);
        creaClienteCompleto("sara", p, "Sara", "Rossi", "sara-rossi12@.com", 2.0);

        // DISTRIBUTORI (Uso gli ID manuali che avevi impostato)
        creaDistributoreCompleto(12345L, 45.46, 9.19, "Online", g1, "dist1", p, 100, 100, 500);
        creaDistributoreCompleto(67890L, 45.47, 9.20, "Online", g1, "dist2", p, 20, 10, 50);
        creaDistributoreCompleto(11111L, 41.90, 12.49, "Online", g2, "dist3", p, 80, 50, 300);
        creaDistributoreCompleto(22222L, 41.91, 12.50, "Guasto", g2, "dist4", p, 0, 0, 0);
        creaDistributoreCompleto(33333L, 40.85, 14.26, "Manutenzione", g3, "dist5", p, 50, 50, 200);
        creaDistributoreCompleto(44444L, 40.86, 14.27, "Online", g3, "dist6", p, 90, 90, 450);

        System.out.println("--- Popolamento completato con successo ---");
    }

    private Gestore creaGestoreCompleto(String username, String passwordCriptata, String nome, String cognome) {
        User u = new User();
        u.setUsername(username);
        u.setPassword(passwordCriptata);
        u.setRuolo(Ruolo.GESTORE);
        entityManager.persist(u); // Uso persist per evitare l'errore di Locking

        Gestore g = new Gestore();
        g.setNome(nome);
        g.setCognome(cognome);
        g.setUser(u);
        entityManager.persist(g);
        return g;
    }

    private void creaManutentoreCompleto(String username, String password, String nome, String cognome, Gestore capo) {
        User u = new User();
        u.setUsername(username);
        u.setPassword(password);
        u.setRuolo(Ruolo.MANUTENTORE);
        entityManager.persist(u);

        Manutentore m = new Manutentore();
        m.setNome(nome);
        m.setCognome(cognome);
        m.setGestore(capo);
        m.setUser(u);
        entityManager.persist(m);
    }

    private void creaClienteCompleto(String username, String password, String nome, String cognome, String mail, Double credito) {
        User u = new User();
        u.setUsername(username);
        u.setPassword(password);
        u.setRuolo(Ruolo.CLIENTE);
        entityManager.persist(u);

        Cliente c = new Cliente();
        c.setNome(nome);
        c.setCognome(cognome);
        c.setMail(mail);
        c.setCredito((double) credito.floatValue());
        c.setUser(u);
        entityManager.persist(c);
    }

    private void creaDistributoreCompleto(Long id, Double lat, Double lon, String stato, Gestore g,
                                          String uName, String uPass,
                                          Integer caffe, Integer latte, Integer acqua) {
        User u = new User();
        u.setUsername(uName);
        u.setPassword(uPass);
        u.setRuolo(Ruolo.DISTRIBUTORE);
        entityManager.persist(u);

        Distributore d = new Distributore();
        d.setId(id); // Qui l'ID manuale ora non darà più problemi
        d.setUser(u);
        d.setLatitudine(lat);
        d.setLongitudine(lon);
        d.setStato(stato);
        d.setGestore(g);
        d.setAttivo(!"Guasto".equals(stato));
        d.setCaffe(caffe);
        d.setLatte(latte);
        d.setAcqua(acqua);
        d.setZucchero(80);
        d.setDecaffeinato(70);
        d.setOrzo(60);
        d.setGinseng(50);
        d.setThe(40);
        d.setCioccolata(90);
        d.setBicchieri(caffe * 2);
        d.setPalette(caffe * 2);
        d.setPompaAcqua("Guasto".equals(stato) ? 0 : 1);
        d.setErogatoreLiquido(1);
        d.setUltimaManutenzione(LocalDate.now());

        entityManager.persist(d);
    }
}