package com.example.appmacchinette.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "clienti")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String cognome;
    private String mail;
    private Double credito = 0.0;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    public Cliente() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCognome() { return cognome; }
    public void setCognome(String cognome) { this.cognome = cognome; }

    public String getMail() { return mail; }
    public void setMail(String mail) { this.mail = mail; }

    public Double getCredito() { return credito; }
    public void setCredito(Double credito) { this.credito = credito; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}