package com.example.appmacchinette.controller.Area_Operativa_e_RealTime;

import com.example.appmacchinette.repository.DistributoreRepository;
import com.example.appmacchinette.service.Service_Area_Operativa_e_RealTime.ManutenzioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/manutentore")
public class ManutentoreApiController {

    @Autowired private ManutenzioneService manutenzioneService;
    @Autowired private DistributoreRepository distributoreRepository;

    @GetMapping("/dettagli/{id}")
    public ResponseEntity<?> getDettagli(@PathVariable Long id) {
        return distributoreRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/cambia-stato")
    public ResponseEntity<?> cambiaStato(@RequestBody Map<String, Object> payload) {
        try {
            Long id = Long.valueOf(payload.get("id").toString());
            String nuovoStato = payload.get("stato").toString();
            manutenzioneService.cambiaStato(id, nuovoStato);
            return ResponseEntity.ok("Stato cambiato");
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/rifornimento-scorte")
    public ResponseEntity<?> rifornimento(@RequestBody Map<String, Object> payload) {
        try {
            Long id = Long.valueOf(payload.get("id").toString());
            manutenzioneService.eseguiRifornimento(id);
            return ResponseEntity.ok("Rifornimento completato!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }

    @PostMapping("/ripara-hardware")
    public ResponseEntity<?> riparaHardware(@RequestBody Map<String, Object> payload) {
        try {
            Long id = Long.valueOf(payload.get("id").toString());
            manutenzioneService.riparaHardware(id);
            return ResponseEntity.ok("Hardware riparato!");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }
}