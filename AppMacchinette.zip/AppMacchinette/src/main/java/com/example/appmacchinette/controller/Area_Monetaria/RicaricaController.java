package com.example.appmacchinette.controller.Area_Monetaria;

import com.example.appmacchinette.service.Service_Area_Monetaria.RicaricaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.security.Principal;

@Controller
public class RicaricaController {

    @Autowired private RicaricaService ricaricaService;

    @GetMapping("/cliente/pagamento")
    public String paginaPagamento(@RequestParam("amount") Double amount, Model model) {
        model.addAttribute("amount", amount);
        return "Carta_Di_Credito";
    }

    @PostMapping("/cliente/ricarica/conferma")
    public String eseguiRicarica(@RequestParam("amount") Double amount, Principal principal) {
        if (principal == null) return "redirect:/login";

        try {
            boolean successo = ricaricaService.eseguiRicarica(principal.getName(), amount);
            if (successo) {
                return "redirect:/cliente/home?successo=ricarica_ok";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/cliente/home?errore=ricarica_fallita";
    }
}