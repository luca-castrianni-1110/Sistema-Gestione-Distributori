package com.example.appmacchinette.controller.Area_Autenticazione;

import com.example.appmacchinette.dto.RegistrationRequest;
import com.example.appmacchinette.service.Service_Area_Autenticazione.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController // per rispondere agli indirizzi internet
@RequestMapping("/api")
public class AuthController {

    @Autowired private AuthService authService;

    @PostMapping("/register")
    public String register(@RequestBody RegistrationRequest req) {
        try {
            authService.registraCliente(req);
            return "OK";
        } catch (Exception e) {
            e.printStackTrace();
            return "Errore server: " + e.getMessage();
        }
    }
}