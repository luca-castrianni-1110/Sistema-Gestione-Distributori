package com.example.appmacchinette.service.Service_Area_Operativa_e_RealTime;

import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.repository.DistributoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ManutenzioneService {

    @Autowired private DistributoreRepository distributoreRepository;

    @Transactional
    public void cambiaStato(Long id, String nuovoStato) {
        Distributore d = distributoreRepository.findById(id).orElseThrow();
        d.setStato(nuovoStato);
        d.setAttivo(nuovoStato.equalsIgnoreCase("Online"));
        distributoreRepository.save(d);
    }

    @Transactional
    public void eseguiRifornimento(Long id) throws Exception {
        Distributore d = distributoreRepository.findById(id).orElseThrow();

        if (!"In Manutenzione".equalsIgnoreCase(d.getStato())) {
            throw new Exception("Azione negata: Attiva prima il toggle Manutenzione!");
        }

        d.setCaffe(100); d.setDecaffeinato(100); d.setOrzo(100);
        d.setLatte(100); d.setCioccolata(100); d.setZucchero(100);
        d.setAcqua(100); d.setGinseng(100); d.setThe(100);
        d.setBicchieri(500); d.setPalette(500);

        distributoreRepository.save(d);
    }

    @Transactional
    public void riparaHardware(Long id) throws Exception {
        Distributore d = distributoreRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Distributore non trovato"));

        if (!"In Manutenzione".equalsIgnoreCase(d.getStato())) {
            throw new Exception("Azione negata: Attiva prima il toggle Manutenzione!");
        }

        d.setPompaAcqua(1);
        d.setErogatoreLiquido(1);
        distributoreRepository.save(d);
    }
}