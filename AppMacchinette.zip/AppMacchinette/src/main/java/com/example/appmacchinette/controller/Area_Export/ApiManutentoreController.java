package com.example.appmacchinette.controller.Area_Export;

import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.Manutentore;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.GestoreRepository;
import com.example.appmacchinette.repository.ManutentoreRepository;
import com.example.appmacchinette.repository.UserRepository;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import java.security.Principal;
import java.util.List;

@Controller
public class ApiManutentoreController {

    @Autowired private ManutentoreRepository manutentoreRepository;
    @Autowired private GestoreRepository gestoreRepository;
    @Autowired private UserRepository userRepository;

    @GetMapping("/api/export/manutentori/xml")
    public void exportManutentoriXml(HttpServletResponse response, Principal principal) {
        try {
            response.setContentType("application/xml");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "attachment; filename=lista_manutentori.xml");

            String username = principal.getName();
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("Utente non trovato"));

            Gestore gestoreCorrente = gestoreRepository.findByUser(user)
                    .orElseThrow(() -> new RuntimeException("Gestore non trovato"));

            List<Manutentore> listaManutentori = manutentoreRepository.findByGestoreId(gestoreCorrente.getId());

            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter writer = factory.createXMLStreamWriter(response.getOutputStream(), "UTF-8");

            writer.writeStartDocument("UTF-8", "1.0");
            writer.writeCharacters("\n");
            writer.writeStartElement("addetti");

            for (Manutentore m : listaManutentori) {
                writer.writeCharacters("\n    ");
                writer.writeStartElement("addetto");

                scriviTag(writer, "id", m.getId().toString());
                scriviTag(writer, "username", m.getUser().getUsername());
                scriviTag(writer, "nome", m.getNome());
                scriviTag(writer, "cognome", m.getCognome());

                writer.writeCharacters("\n    ");
                writer.writeEndElement();
            }

            writer.writeCharacters("\n");
            writer.writeEndElement();
            writer.writeEndDocument();

            writer.flush();
            writer.close();

        } catch (Exception e) {
            System.err.println("Errore export Manutentori: " + e.getMessage());
        }
    }

    private void scriviTag(XMLStreamWriter writer, String tag, String valore) throws Exception {
        writer.writeCharacters("\n        ");
        writer.writeStartElement(tag);
        writer.writeCharacters(valore != null ? valore : "");
        writer.writeEndElement();
    }
}