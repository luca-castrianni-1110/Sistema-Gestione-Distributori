package com.example.appmacchinette.service.Service_Area_Gestore;

import com.example.appmacchinette.dto.ManutentoreRequest;
import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.Manutentore;
import com.example.appmacchinette.entity.Ruolo;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.GestoreRepository;
import com.example.appmacchinette.repository.ManutentoreRepository;
import com.example.appmacchinette.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Random;

@Service
public class PersonaleService {

    @Autowired private ManutentoreRepository manutentoreRepository;
    @Autowired private GestoreRepository gestoreRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    @Transactional
    public Long aggiungiManutentore(ManutentoreRequest req, String usernameGestore) throws Exception {
        User userGestore = userRepository.findByUsername(usernameGestore)
                .orElseThrow(() -> new RuntimeException("Utente gestore non trovato"));
        Gestore gestore = gestoreRepository.findByUser(userGestore)
                .orElseThrow(() -> new RuntimeException("Profilo gestore non trovato"));

        if (userRepository.findByUsername(req.getUsername()).isPresent()) {
            throw new Exception("Username già in uso!");
        }

        User newUser = new User();
        Long userId = generaIdUnivocoUser();
        newUser.setId(userId);
        newUser.setUsername(req.getUsername());
        newUser.setPassword(passwordEncoder.encode(req.getPassword()));
        newUser.setRuolo(Ruolo.MANUTENTORE);
        newUser = userRepository.save(newUser);

        Manutentore nuovoAddetto = new Manutentore();
        Long manutentoreId = generaIdUnivocoManutentore();
        nuovoAddetto.setId(manutentoreId);
        nuovoAddetto.setNome(req.getNome());
        nuovoAddetto.setCognome(req.getCognome());
        nuovoAddetto.setGestore(gestore);
        nuovoAddetto.setUser(newUser);
        manutentoreRepository.save(nuovoAddetto);

        return manutentoreId;
    }

    @Transactional
    public String rimuoviManutentore(String usernameDaRimuovere, String usernameGestore) throws Exception {
        User userGestore = userRepository.findByUsername(usernameGestore).orElseThrow();
        Gestore gestore = gestoreRepository.findByUser(userGestore).orElseThrow();

        Optional<User> targetUserOpt = userRepository.findByUsername(usernameDaRimuovere);
        if (targetUserOpt.isEmpty()) {
            throw new Exception("Utente non trovato.");
        }
        User targetUser = targetUserOpt.get();

        Manutentore manutentoreDaEliminare = manutentoreRepository.findByUser(targetUser);

        if (manutentoreDaEliminare == null) {
            userRepository.delete(targetUser);
            return "Utente rimosso (nessun profilo manutentore trovato).";
        }

        if (!manutentoreDaEliminare.getGestore().getId().equals(gestore.getId())) {
            throw new Exception("Non puoi eliminare un manutentore non tuo!");
        }

        manutentoreRepository.delete(manutentoreDaEliminare);
        userRepository.delete(targetUser);

        return "Manutentore rimosso correttamente.";
    }

    private Long generaIdUnivocoUser() {
        Random rand = new Random();
        Long id;
        do { id = (long) (rand.nextInt(999) + 1); } while (userRepository.existsById(id));
        return id;
    }

    private Long generaIdUnivocoManutentore() {
        Random rand = new Random();
        Long id;
        do { id = (long) (rand.nextInt(999) + 1); } while (manutentoreRepository.existsById(id));
        return id;
    }
}