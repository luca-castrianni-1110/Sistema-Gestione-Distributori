package com.example.appmacchinette.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Gestore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String cognome;

    @OneToMany(mappedBy = "gestore")
    private List<Manutentore> manutentori;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    public Gestore() {}

    public Gestore(String nome, String cognome, User user) {
        this.nome = nome;
        this.cognome = cognome;
        this.user = user;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public List<Manutentore> getManutentori() {
        return manutentori;
    }

    public void setManutentori(List<Manutentore> manutentori) {
        this.manutentori = manutentori;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}