package com.example.appmacchinette.entity;

public enum Ruolo {
    GESTORE,
    MANUTENTORE,
    DISTRIBUTORE,
    CLIENTE
}