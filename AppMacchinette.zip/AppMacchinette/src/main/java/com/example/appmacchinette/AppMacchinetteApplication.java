package com.example.appmacchinette;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppMacchinetteApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppMacchinetteApplication.class, args);
    }

}
