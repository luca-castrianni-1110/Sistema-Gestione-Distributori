package com.example.appmacchinette.controller.Area_Gestore;
import com.example.appmacchinette.dto.DistributoreStatoRequest;
import com.example.appmacchinette.service.Service_Area_Gestore.DistributoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;

@RestController
@RequestMapping("/api/gestore")
public class GestioneDistributoriController {

    @Autowired private DistributoreService distributoreService;

    @PostMapping("/cambia-stato")
    public ResponseEntity<String> cambiaStato(@RequestBody DistributoreStatoRequest req, Principal principal) {
        try {
            distributoreService.cambiaStato(req, principal.getName());
            return ResponseEntity.ok("Stato aggiornato a " + req.getNuovoStato());
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("ID Distributore non valido");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore: " + e.getMessage());
        }
    }
}