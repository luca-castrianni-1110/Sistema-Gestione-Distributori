package com.example.appmacchinette.service.Service_Area_Monetaria;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.repository.ClienteRepository;
import com.example.appmacchinette.repository.DistributoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PagamentoService {

    @Autowired private ClienteRepository clienteRepository;
    @Autowired private DistributoreRepository distributoreRepository;

    @Transactional
    public String eseguiErogazione(Long idDistributore, Double prezzo, String bevanda, Integer zucchero) {
        Distributore d = distributoreRepository.findById(idDistributore).orElse(null);
        if (d == null) return "distributore_non_trovato";

        Cliente c = d.getUtenteConnesso();
        if (c == null) return "utente_scollegato";

        if (c.getCredito() == null || c.getCredito() < prezzo) {
            return "credito_insufficiente";
        }

        if (!isProdottoDisponibile(d, bevanda, zucchero)) {
            return "prodotto_esaurito";
        }

        c.setCredito(c.getCredito() - prezzo);
        clienteRepository.save(c);

        scalaScorte(d, bevanda, zucchero);

        d.setUtenteConnesso(c); //Mantengo la connessione
        distributoreRepository.save(d);

        return "OK";
    }

    private boolean isProdottoDisponibile(Distributore d, String bevanda, Integer livelloZucchero) {
        int qBicchieri = safeGet(d.getBicchieri());
        int qAcqua = safeGet(d.getAcqua());
        int qPalette = safeGet(d.getPalette());
        int qZucchero = safeGet(d.getZucchero());

        if (qBicchieri < 1 || qAcqua < 1) return false;
        if (livelloZucchero > 0 && (qZucchero < livelloZucchero || qPalette < 1)) return false;

        switch (bevanda) {
            case "caffe_espresso": case "caffe_lungo": return safeGet(d.getCaffe()) >= 1;
            case "caffe_macchiato": case "cappuccino": return safeGet(d.getCaffe()) >= 1 && safeGet(d.getLatte()) >= 1;
            case "cioccolata": return safeGet(d.getCioccolata()) >= 1 && safeGet(d.getLatte()) >= 1;
            case "caffe_ginseng": return safeGet(d.getGinseng()) >= 1;
            case "caffe_orzo": return safeGet(d.getOrzo()) >= 1;
            case "the_limone": return safeGet(d.getThe()) >= 1;
            case "caffe_decaffeinato": return safeGet(d.getDecaffeinato()) >= 1;
            default: return false;
        }
    }

    private void scalaScorte(Distributore d, String bevanda, Integer livelloZucchero) {
        d.setBicchieri(Math.max(0, safeGet(d.getBicchieri()) - 1));
        d.setAcqua(Math.max(0, safeGet(d.getAcqua()) - 1));
        if (livelloZucchero > 0) {
            d.setZucchero(Math.max(0, safeGet(d.getZucchero()) - livelloZucchero));
            d.setPalette(Math.max(0, safeGet(d.getPalette()) - 1));
        }
        switch (bevanda) {
            case "caffe_espresso": case "caffe_lungo": d.setCaffe(Math.max(0, safeGet(d.getCaffe()) - 1)); break;
            case "caffe_macchiato": case "cappuccino":
                d.setCaffe(Math.max(0, safeGet(d.getCaffe()) - 1));
                d.setLatte(Math.max(0, safeGet(d.getLatte()) - 1)); break;
            case "cioccolata":
                d.setCioccolata(Math.max(0, safeGet(d.getCioccolata()) - 1));
                d.setLatte(Math.max(0, safeGet(d.getLatte()) - 1)); break;
            case "caffe_ginseng": d.setGinseng(Math.max(0, safeGet(d.getGinseng()) - 1)); break;
            case "caffe_orzo": d.setOrzo(Math.max(0, safeGet(d.getOrzo()) - 1)); break;
            case "the_limone": d.setThe(Math.max(0, safeGet(d.getThe()) - 1)); break;
            case "caffe_decaffeinato": d.setDecaffeinato(Math.max(0, safeGet(d.getDecaffeinato()) - 1)); break;
        }
    }

    private int safeGet(Integer val) { return val != null ? val : 0; }
}