package com.example.appmacchinette.service.Service_Area_Monetaria;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.ClienteRepository;
import com.example.appmacchinette.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RicaricaService {

    @Autowired private UserRepository userRepository;
    @Autowired private ClienteRepository clienteRepository;

    @Transactional
    public boolean eseguiRicarica(String username, Double amount) {
        User user = userRepository.findByUsername(username).orElse(null);
        if (user != null) {
            Cliente c = clienteRepository.findByUser(user);
            if (c != null && amount > 0) {
                double nuovoCredito = (c.getCredito() != null ? c.getCredito() : 0.0) + amount;
                c.setCredito(nuovoCredito);
                clienteRepository.save(c);
                return true;
            }
        }
        return false;
    }
}