package com.example.appmacchinette.entity;

import jakarta.persistence.*;
import org.springframework.data.domain.Persistable; // <--- IMPORTANTE

@Entity
public class Manutentore implements Persistable<Long> {

    @Id
    private Long id;

    private String nome;
    private String cognome;

    @ManyToOne
    @JoinColumn(name = "id_gestore", nullable = false)
    private Gestore gestore;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean isNew() {
        return isNew;
    }

    @PostLoad
    @PostPersist
    void markNotNew() {
        this.isNew = false;
    }

    public Manutentore() {}

    @Override
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCognome() { return cognome; }
    public void setCognome(String cognome) { this.cognome = cognome; }

    public Gestore getGestore() { return gestore; }
    public void setGestore(Gestore gestore) { this.gestore = gestore; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}