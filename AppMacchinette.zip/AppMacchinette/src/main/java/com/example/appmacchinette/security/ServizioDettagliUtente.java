package com.example.appmacchinette.security;

import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


//La creo per far capire a springsecurity dove prendere l utente quando clicco Login
// la chiama in auotmatico sprig quando devo fare il login e cerca una classe che implementa UserDetailsService
@Service
public class ServizioDettagliUtente implements UserDetailsService {

    @Autowired private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Utente non trovato: " + username));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword())
                .authorities("ROLE_" + user.getRuolo().toString())
                .build();
    }
}