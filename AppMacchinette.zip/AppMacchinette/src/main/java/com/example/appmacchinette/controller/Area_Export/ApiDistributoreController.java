package com.example.appmacchinette.controller.Area_Export;

import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.Manutentore;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.DistributoreRepository;
import com.example.appmacchinette.repository.GestoreRepository;
import com.example.appmacchinette.repository.ManutentoreRepository;
import com.example.appmacchinette.repository.UserRepository;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ApiDistributoreController {

    @Autowired private DistributoreRepository distributoreRepository;
    @Autowired private GestoreRepository gestoreRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private ManutentoreRepository manutentoreRepository;

    @GetMapping("/api/export/xml")
    public void exportDistributoriXml(HttpServletResponse response, Principal principal) throws IOException {
        try {
            response.setContentType("application/xml");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "inline; filename=distributori.xml");

            List<Distributore> distributori = new ArrayList<>();

            if (principal == null) {
                distributori = distributoreRepository.findAll();
            } else {
                String username = principal.getName();
                User user = userRepository.findByUsername(username).orElse(null);

                if (user != null) {
                    String ruolo = user.getRuolo().toString();

                    if (ruolo.contains("GESTORE")) {
                        Gestore gestore = gestoreRepository.findByUser(user).orElse(null);
                        if (gestore != null) {
                            distributori = distributoreRepository.findByGestore(gestore);
                        }
                    }
                    else if (ruolo.contains("MANUTENTORE")) {
                        Manutentore manutentore = manutentoreRepository.findByUser(user);


                        if (manutentore != null && manutentore.getGestore() != null) {

                            Gestore capoDelManutentore = manutentore.getGestore();

                            distributori = distributoreRepository.findByGestore(capoDelManutentore);
                        }
                    }
                    else {
                        distributori = distributoreRepository.findAll();
                    }
                }
            }

            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter writer = factory.createXMLStreamWriter(response.getOutputStream(), "UTF-8");

            writer.writeStartDocument("UTF-8", "1.0");
            writer.writeCharacters("\n");
            writer.writeStartElement("ListaDistributori");

            for (Distributore d : distributori) {
                writer.writeCharacters("\n    ");
                writer.writeStartElement("Distributore");

                scriviTag(writer, "Id", String.valueOf(d.getId()));
                scriviTag(writer, "Latitudine", d.getLatitudine() != null ? String.valueOf(d.getLatitudine()) : "0");
                scriviTag(writer, "Longitudine", d.getLongitudine() != null ? String.valueOf(d.getLongitudine()) : "0");
                scriviTag(writer, "Stato", d.getStato() != null ? d.getStato() : "Sconosciuto");

                scriviTag(writer, "Guasto", d.getMessaggioGuasto() != null ? d.getMessaggioGuasto() : "");
                scriviTag(writer, "UltimaManutenzione", d.getUltimaManutenzione() != null ? d.getUltimaManutenzione().toString() : "");

                writer.writeCharacters("\n    ");
                writer.writeEndElement();
            }

            writer.writeCharacters("\n");
            writer.writeEndElement();
            writer.writeEndDocument();

            writer.flush();
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private void scriviTag(XMLStreamWriter writer, String tag, String valore) throws Exception {
        writer.writeCharacters("\n        ");
        writer.writeStartElement(tag);
        writer.writeCharacters(valore != null ? valore : "");
        writer.writeEndElement();
    }
}