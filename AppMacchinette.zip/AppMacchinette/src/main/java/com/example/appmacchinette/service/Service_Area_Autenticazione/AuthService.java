package com.example.appmacchinette.service.Service_Area_Autenticazione;

import com.example.appmacchinette.dto.RegistrationRequest;
import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Ruolo;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.ClienteRepository;
import com.example.appmacchinette.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    @Autowired private UserRepository userRepository;
    @Autowired private ClienteRepository clienteRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    @Transactional //lo uso per garantirmi che o tutte le richieste vengono eseguite correttamente oppuire torna tutto come prima
    public void registraCliente(RegistrationRequest req) throws Exception {
        if(userRepository.findByUsername(req.getUsername()).isPresent()) {
            throw new Exception("Username esistente");
        }

        User u = new User();
        u.setUsername(req.getUsername());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setRuolo(Ruolo.CLIENTE);
        userRepository.save(u);

        Cliente c = new Cliente();
        c.setNome(req.getNome());
        c.setCognome(req.getCognome());
        c.setMail(req.getEmail());
        c.setCredito(0.0);
        c.setUser(u);
        clienteRepository.save(c);
    }
}