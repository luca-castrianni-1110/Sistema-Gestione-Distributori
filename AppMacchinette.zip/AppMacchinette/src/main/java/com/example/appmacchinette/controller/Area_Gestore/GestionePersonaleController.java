package com.example.appmacchinette.controller.Area_Gestore;

import com.example.appmacchinette.dto.ManutentoreRequest;
import com.example.appmacchinette.service.Service_Area_Gestore.PersonaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;

@RestController
@RequestMapping("/api/gestore")
public class GestionePersonaleController {

    @Autowired private PersonaleService personaleService;

    @PostMapping("/aggiungi-manutentore")
    public ResponseEntity<String> aggiungiManutentore(@RequestBody ManutentoreRequest req, Principal principal) {
        try {
            Long id = personaleService.aggiungiManutentore(req, principal.getName());
            return ResponseEntity.ok("Manutentore aggiunto con successo! (ID: " + id + ")");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Errore durante l'aggiunta: " + e.getMessage());
        }
    }

    @PostMapping("/rimuovi-manutentore")
    public ResponseEntity<String> rimuoviManutentore(@RequestBody ManutentoreRequest req, Principal principal) {
        try {
            String msg = personaleService.rimuoviManutentore(req.getUsername(), principal.getName());
            return ResponseEntity.ok(msg);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Errore rimozione: " + e.getMessage());
        }
    }
}