package com.example.appmacchinette.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Set;

@Component
public class GestoreSuccessoLogin implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        Set<String> ruoli = AuthorityUtils.authorityListToSet(authentication.getAuthorities());

        if (ruoli.contains("ROLE_GESTORE")) {
            response.sendRedirect("/gestore/dashboard");
        }
        else if (ruoli.contains("ROLE_MANUTENTORE")) {
            response.sendRedirect("/manutentore/tasks");
        }
        else if (ruoli.contains("ROLE_CLIENTE")) {
            response.sendRedirect("/cliente/home");
        }
        else if (ruoli.contains("ROLE_DISTRIBUTORE")) {
            response.sendRedirect("/distributore/interfaccia");
        }
        else {
            response.sendRedirect("/login");
        }
    }
}