package com.example.appmacchinette.service.Service_Area_Gestore;

import com.example.appmacchinette.dto.DistributoreRequest;
import com.example.appmacchinette.dto.DistributoreStatoRequest;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.Ruolo;
import com.example.appmacchinette.entity.User;
import com.example.appmacchinette.repository.DistributoreRepository;
import com.example.appmacchinette.repository.GestoreRepository;
import com.example.appmacchinette.repository.UserRepository;
import com.example.appmacchinette.service.Jackarta.JakartaIntegrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Random;

@Service
public class DistributoreService {

    @Autowired private DistributoreRepository distributoreRepository;
    @Autowired private GestoreRepository gestoreRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private JakartaIntegrationService jakartaService;
    @Autowired private PasswordEncoder passwordEncoder;

    @Transactional
    public Long aggiungiDistributore(DistributoreRequest req, String usernameGestore) throws Exception {
        User userGestore = userRepository.findByUsername(usernameGestore).orElseThrow();
        Gestore gestore = gestoreRepository.findByUser(userGestore).orElseThrow();

        if (userRepository.findByUsername(req.getUsername()).isPresent()) {
            throw new Exception("Username già in uso!");
        }

        Long newId = generaIdUnivocoDistributore();

        User newUser = new User();
        newUser.setId(generaIdUnivocoUser());
        newUser.setUsername(req.getUsername());
        newUser.setPassword(passwordEncoder.encode(req.getPassword()));
        newUser.setRuolo(Ruolo.DISTRIBUTORE);
        newUser = userRepository.save(newUser);

        Distributore d = new Distributore();
        d.setId(newId);
        d.setLatitudine(req.getLat());
        d.setLongitudine(req.getLon());
        d.setAttivo(true);
        d.setStato("Manutenzione");
        d.setCaffe(100); d.setLatte(100); d.setAcqua(100); d.setZucchero(100);
        d.setDecaffeinato(100); d.setOrzo(100); d.setGinseng(100); d.setThe(100); d.setCioccolata(100);
        d.setBicchieri(200); d.setPalette(200);
        d.setPompaAcqua(1); d.setErogatoreLiquido(1);
        d.setGestore(gestore);
        d.setUser(newUser);

        distributoreRepository.save(d);

        req.setId(String.valueOf(newId));
        jakartaService.notificaAggiuntaJakarta(req);

        return newId;
    }

    @Transactional
    public void rimuoviDistributore(String idDist, String usernameGestore) throws Exception {
        User userGestore = userRepository.findByUsername(usernameGestore).orElseThrow();
        Gestore gestore = gestoreRepository.findByUser(userGestore).orElseThrow();

        Long id = Long.parseLong(idDist);
        Distributore d = distributoreRepository.findById(id)
                .orElseThrow(() -> new Exception("Distributore non trovato."));

        if (!d.getGestore().getId().equals(gestore.getId())) {
            throw new Exception("Non è un tuo distributore!");
        }

        if (d.getUser() != null) {
            User u = d.getUser();
            d.setUser(null);
            userRepository.delete(u);
        }
        if(d.getUtenteConnesso() != null) {
            d.setUtenteConnesso(null);
        }

        distributoreRepository.delete(d);

        try {
            jakartaService.notificaRimozioneJakarta(idDist);
        } catch (Exception e) {
            System.out.println("Jakarta offline, rimozione locale OK.");
        }
    }

    @Transactional
    public void cambiaStato(DistributoreStatoRequest req, String usernameGestore) throws Exception {
        User user = userRepository.findByUsername(usernameGestore).orElseThrow();
        Gestore gestore = gestoreRepository.findByUser(user).orElseThrow();

        Long idDist = Long.parseLong(req.getIdDistributore());
        Distributore dist = distributoreRepository.findById(idDist)
                .orElseThrow(() -> new RuntimeException("Distributore non trovato"));

        if (!dist.getGestore().getId().equals(gestore.getId())) {
            throw new Exception("Non puoi modificare un distributore non tuo!");
        }

        String nuovoStato = req.getNuovoStato();
        dist.setStato(nuovoStato);

        boolean isOnline = "Online".equalsIgnoreCase(nuovoStato);
        dist.setAttivo(isOnline);

        dist.setStato(req.getNuovoStato());
        distributoreRepository.save(dist);
    }

    private Long generaIdUnivocoUser() {
        Random rand = new Random();
        Long id;
        do { id = (long) (rand.nextInt(999) + 1); } while (userRepository.existsById(id));
        return id;
    }

    private Long generaIdUnivocoDistributore() {
        Random rand = new Random();
        Long id;
        do { id = (long) (rand.nextInt(9900) + 100); } while (distributoreRepository.existsById(id));
        return id;
    }
}