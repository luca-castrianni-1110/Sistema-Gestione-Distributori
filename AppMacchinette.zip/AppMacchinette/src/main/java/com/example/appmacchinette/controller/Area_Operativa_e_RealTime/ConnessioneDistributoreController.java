package com.example.appmacchinette.controller.Area_Operativa_e_RealTime;

import com.example.appmacchinette.service.Service_Area_Operativa_e_RealTime.ConnessioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/connessione")
public class ConnessioneDistributoreController {

    @Autowired private ConnessioneService connessioneService;

    @PostMapping("/login-fisico")
    public ResponseEntity<String> connetti(@RequestParam("idDistributore") String idString,
                                           @RequestParam("idCliente") Long idCliente) {
        try {
            Long idDistributore = Long.parseLong(idString.trim());
            String risultato = connessioneService.connettiUtente(idDistributore, idCliente);

            if ("OK".equals(risultato)) {
                return ResponseEntity.ok("Connessione riuscita");
            } else if (risultato.startsWith("BLOCCATO")) {
                return ResponseEntity.status(403).body(risultato);
            } else {
                return ResponseEntity.status(404).body(risultato);
            }
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("ID non valido.");
        }
    }

    @PostMapping("/logout-fisico")
    public ResponseEntity<String> disconnetti(@RequestParam("idDistributore") String idString) {
        try {
            connessioneService.disconnettiUtente(Long.parseLong(idString));
            return ResponseEntity.ok("Disconnesso");
        } catch (Exception e) {
            return ResponseEntity.ok("Errore logout ignorato");
        }
    }
}