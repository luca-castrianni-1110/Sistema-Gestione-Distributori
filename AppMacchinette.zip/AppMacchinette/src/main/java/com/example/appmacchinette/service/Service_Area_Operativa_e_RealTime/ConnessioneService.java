package com.example.appmacchinette.service.Service_Area_Operativa_e_RealTime;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.repository.ClienteRepository;
import com.example.appmacchinette.repository.DistributoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConnessioneService {

    @Autowired private DistributoreRepository distributoreRepository;
    @Autowired private ClienteRepository clienteRepository;

    @Transactional
    public String connettiUtente(Long idDistributore, Long idCliente) {
        Distributore distributore = distributoreRepository.findById(idDistributore).orElse(null);
        if (distributore == null) return "Distributore inesistente.";

        if (!"Online".equalsIgnoreCase(distributore.getStato())) {
            return "BLOCCATO: Distributore " + distributore.getStato();
        }

        Cliente cliente = clienteRepository.findById(idCliente).orElse(null);
        if (cliente == null) return "Cliente non trovato.";

        Distributore vecchio = distributoreRepository.findByUtenteConnesso(cliente);
        if (vecchio != null) {
            vecchio.setUtenteConnesso(null);
            distributoreRepository.save(vecchio);
        }

        distributore.setUtenteConnesso(cliente);
        distributoreRepository.save(distributore);
        return "OK";
    }

    @Transactional
    public void disconnettiUtente(Long idDistributore) {
        Distributore distributore = distributoreRepository.findById(idDistributore).orElse(null);
        if (distributore != null) {
            distributore.setUtenteConnesso(null);
            distributoreRepository.save(distributore);
        }
    }
}