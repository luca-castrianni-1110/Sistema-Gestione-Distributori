package com.example.appmacchinette.repository;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.entity.Gestore;
import com.example.appmacchinette.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;


@Repository
public interface DistributoreRepository extends JpaRepository<Distributore, Long> {

    Distributore findByUser(User user);
    Distributore findByUtenteConnesso(Cliente utenteConnesso);
    List<Distributore> findByGestore(Gestore gestoreCorrente);
}