package com.example.appmacchinette.dto;

public class DistributoreStatoRequest {
    private String idDistributore;
    private String nuovoStato;

    public String getIdDistributore() { return idDistributore; }
    public void setIdDistributore(String idDistributore) { this.idDistributore = idDistributore; }

    public String getNuovoStato() { return nuovoStato; }
    public void setNuovoStato(String nuovoStato) { this.nuovoStato = nuovoStato; }
}