package com.example.appmacchinette.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "distributore")
public class Distributore {

    @Id
    private Long id;

    private Double latitudine;
    private Double longitudine;
    private String stato;
    @Column(name = "attivo")
    private Boolean attivo;

    private LocalDate ultimaManutenzione;
    private LocalDate prossimaManutenzione;
    private String messaggioGuasto;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "gestore_id")
    private Gestore gestore;

    @JsonIgnore
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @JsonIgnore
    @OneToOne
    @JoinColumn(name = "utente_connesso_id", referencedColumnName = "id", nullable = true)
    private Cliente utenteConnesso;

    private Integer caffe;
    private Integer decaffeinato;
    private Integer orzo;
    private Integer latte;
    private Integer cioccolata;
    private Integer zucchero;
    private Integer acqua;

    private Integer ginseng;
    private Integer the;
    private Integer bicchieri;
    private Integer palette;

    private Integer pompaAcqua; // 1 = OK, 0 = GUASTO
    private Integer erogatoreLiquido; // 1 = OK, 0 = GUASTO

    public Distributore() {}


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getLatitudine() { return latitudine; }
    public void setLatitudine(Double latitudine) { this.latitudine = latitudine; }

    public Double getLongitudine() { return longitudine; }
    public void setLongitudine(Double longitudine) { this.longitudine = longitudine; }

    public String getStato() { return stato; }
    public void setStato(String stato) { this.stato = stato; }

    public Boolean getAttivo() { return attivo; }
    public void setAttivo(Boolean attivo) { this.attivo = attivo; }

    public LocalDate getUltimaManutenzione() { return ultimaManutenzione; }
    public void setUltimaManutenzione(LocalDate ultimaManutenzione) { this.ultimaManutenzione = ultimaManutenzione; }

    public String getMessaggioGuasto() { return messaggioGuasto; }
    public void setMessaggioGuasto(String messaggioGuasto) { this.messaggioGuasto = messaggioGuasto; }

    public Gestore getGestore() { return gestore; }
    public void setGestore(Gestore gestore) { this.gestore = gestore; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Cliente getUtenteConnesso() { return utenteConnesso; }
    public void setUtenteConnesso(Cliente utenteConnesso) { this.utenteConnesso = utenteConnesso; }

    public Integer getCaffe() { return caffe; }
    public void setCaffe(Integer caffe) { this.caffe = caffe; }

    public Integer getDecaffeinato() { return decaffeinato; }
    public void setDecaffeinato(Integer decaffeinato) { this.decaffeinato = decaffeinato; }

    public Integer getOrzo() { return orzo; }
    public void setOrzo(Integer orzo) { this.orzo = orzo; }

    public Integer getLatte() { return latte; }
    public void setLatte(Integer latte) { this.latte = latte; }

    public Integer getCioccolata() { return cioccolata; }
    public void setCioccolata(Integer cioccolata) { this.cioccolata = cioccolata; }

    public Integer getZucchero() { return zucchero; }
    public void setZucchero(Integer zucchero) { this.zucchero = zucchero; }

    public Integer getAcqua() { return acqua; }
    public void setAcqua(Integer acqua) { this.acqua = acqua; }

    public Integer getGinseng() { return ginseng; }
    public void setGinseng(Integer ginseng) { this.ginseng = ginseng; }

    public Integer getThe() { return the; }
    public void setThe(Integer the) { this.the = the; }

    public Integer getBicchieri() { return bicchieri; }
    public void setBicchieri(Integer bicchieri) { this.bicchieri = bicchieri; }

    public Integer getPalette() { return palette; }
    public void setPalette(Integer palette) { this.palette = palette; }

    public Integer getPompaAcqua() { return pompaAcqua; }
    public void setPompaAcqua(Integer pompaAcqua) { this.pompaAcqua = pompaAcqua; }


    public Integer getErogatoreLiquido() { return erogatoreLiquido; }
    public void setErogatoreLiquido(Integer erogatoreLiquido) { this.erogatoreLiquido = erogatoreLiquido; }
}