package com.example.appmacchinette.controller.Area_Operativa_e_RealTime;

import com.example.appmacchinette.entity.Cliente;
import com.example.appmacchinette.entity.Distributore;
import com.example.appmacchinette.repository.DistributoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

//La uso per aggiornare in automatico il mio distributore senza ricaricare la pagina tramite la chiamata del javascript ogni 2 secondi
@RestController
@RequestMapping("/api/macchinetta")
public class MacchinettaRestController {

    @Autowired
    private DistributoreRepository distributoreRepository;

    @GetMapping("/{id}/verifica-connessione")
    public Map<String, Object> verificaStato(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        Distributore d = distributoreRepository.findById(id).orElse(null);

        if (d != null) {
            Cliente c = d.getUtenteConnesso();
            if (c != null) {
                response.put("connesso", true);
                response.put("clienteNome", c.getNome());
                response.put("credito", c.getCredito());
            } else {
                response.put("connesso", false);
            }

            response.put("stato", d.getStato());

            response.put("scortaLatte", d.getLatte() != null ? d.getLatte() : 0);
            response.put("scortaGinseng", d.getGinseng() != null ? d.getGinseng() : 0);
            response.put("scortaThe", d.getThe() != null ? d.getThe() : 0);
            response.put("scortaOrzo", d.getOrzo() != null ? d.getOrzo() : 0);
            response.put("scortaCioccolata", d.getCioccolata() != null ? d.getCioccolata() : 0);
            response.put("scortaCaffe", d.getCaffe() != null ? d.getCaffe() : 0);
            response.put("scortaBicchieri", d.getBicchieri() != null ? d.getBicchieri() : 0);

        } else {
            response.put("errore", "Distributore non trovato");
        }

        return response;
    }
}