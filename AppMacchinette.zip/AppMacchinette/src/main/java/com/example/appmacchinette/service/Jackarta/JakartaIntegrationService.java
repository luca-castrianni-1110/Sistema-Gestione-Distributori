package com.example.appmacchinette.service.Jackarta;

import com.example.appmacchinette.dto.DistributoreRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class JakartaIntegrationService {

    private static final String JAKARTA_BASE_URL = "http://localhost:8081/monitoraggio_mongo_war_exploded/distributori/";

    private final RestTemplate restTemplate = new RestTemplate();


    public void notificaAggiuntaJakarta(DistributoreRequest req) {
        try {
            restTemplate.postForObject(JAKARTA_BASE_URL, req, String.class);
            System.out.println(" Distributore " + req.getId() + " inviato a Jakarta.");
        } catch (Exception e) {
            System.err.println("Impossibile contattare Jakarta per aggiunta: " + e.getMessage());
        }
    }


    public void notificaRimozioneJakarta(String idDistributore) {
        try {
            String urlSpecifica = JAKARTA_BASE_URL + idDistributore;

            restTemplate.delete(urlSpecifica);
            System.out.println(" [SYNC] Richiesta rimozione ID " + idDistributore + " inviata a Jakarta.");
        } catch (Exception e) {
            System.err.println(" [SYNC ERROR] Impossibile contattare Jakarta per rimozione: " + e.getMessage());
        }
    }
}