package com.example.appmacchinette.service.Jackarta;

import com.example.appmacchinette.dto.DistributoreRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class JakartaIntegrationService {

    @Value("${server.jakarta.url}")
    private String jakartaBaseUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public void notificaAggiuntaJakarta(DistributoreRequest req) {
        try {
            restTemplate.postForObject(jakartaBaseUrl, req, String.class);
            System.out.println(" Distributore " + req.getId() + " inviato a Jakarta.");
        } catch (Exception e) {
            System.err.println("Impossibile contattare Jakarta per aggiunta: " + e.getMessage());
        }
    }

    public void notificaRimozioneJakarta(String idDistributore) {
        try {
            String urlSpecifica = jakartaBaseUrl + idDistributore;

            restTemplate.delete(urlSpecifica);
            System.out.println(" [SYNC] Richiesta rimozione ID " + idDistributore + " inviata a Jakarta.");
        } catch (Exception e) {
            System.err.println(" [SYNC ERROR] Impossibile contattare Jakarta per rimozione: " + e.getMessage());
        }
    }
}