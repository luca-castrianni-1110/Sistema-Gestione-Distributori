package com.example.appmacchinette.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class ConfigurazioneSicurezza {

    @Autowired
    private GestoreSuccessoLogin gestoreSuccessoLogin;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // CSRF li ho disabilitati per semplicita
                .authorizeHttpRequests((requests) -> requests
                        // Pagine accessibili a tutti
                        .requestMatchers("/login", "/perform_login", "/CSS/**", "/JS/**", "/images/**").permitAll()
                        .requestMatchers("/pagamento/**").permitAll()
                        .requestMatchers("/api/export/**").permitAll()

                        .requestMatchers("/cliente/logout-distributore").authenticated()

                        .requestMatchers("/cliente/distributore").permitAll()
                        // API generiche richiedono login
                        .requestMatchers("/api/**").authenticated()

                        // REGOLE RUOLI
                        .requestMatchers("/cliente/**").hasAnyAuthority("ROLE_CLIENTE", "CLIENTE")
                        .requestMatchers("/gestore/**").hasAnyAuthority("ROLE_GESTORE", "GESTORE")
                        .requestMatchers("/api/manutentore/**").hasAnyAuthority("ROLE_MANUTENTORE", "MANUTENTORE")
                        .requestMatchers("/distributore/**").hasAnyAuthority("ROLE_DISTRIBUTORE", "DISTRIBUTORE")

                        // Tutto il resto richiede autenticazione
                        .anyRequest().authenticated()
                )
                .formLogin((form) -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/perform_login")
                        .usernameParameter("User")
                        .passwordParameter("Password_registrazione")
                        .successHandler(gestoreSuccessoLogin)
                        .failureUrl("/login?error=true")
                        .permitAll()
                )
                .logout((logout) -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}