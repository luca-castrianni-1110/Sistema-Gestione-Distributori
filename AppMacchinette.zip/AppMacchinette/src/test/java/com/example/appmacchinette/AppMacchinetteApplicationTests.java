package com.example.appmacchinette;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppMacchinetteApplicationTests {

    @Test
    void contextLoads() {
    }

}
